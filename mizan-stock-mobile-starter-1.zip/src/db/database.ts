import * as SQLite from 'expo-sqlite';
import * as FileSystem from 'expo-file-system/legacy';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';

type DB = SQLite.SQLiteDatabase;
const now = () => new Date().toISOString();
const dateKey = (d = new Date()) => d.toISOString().slice(0,10);

export async function initializeDatabase(db: DB) {
  await db.execAsync(`
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL CHECK(length(trim(name)) > 0),
      barcode TEXT UNIQUE,
      buy_price INTEGER NOT NULL CHECK(buy_price >= 0),
      sell_price INTEGER NOT NULL CHECK(sell_price >= 0),
      quantity INTEGER NOT NULL CHECK(quantity >= 0),
      low_stock_threshold INTEGER NOT NULL DEFAULT 3 CHECK(low_stock_threshold >= 0),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      idempotency_key TEXT NOT NULL UNIQUE,
      subtotal INTEGER NOT NULL CHECK(subtotal >= 0),
      discount INTEGER NOT NULL CHECK(discount >= 0),
      total INTEGER NOT NULL CHECK(total >= 0),
      estimated_profit INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
      product_id INTEGER NOT NULL REFERENCES products(id),
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL CHECK(quantity > 0),
      unit_buy_price INTEGER NOT NULL,
      unit_sell_price INTEGER NOT NULL,
      line_total INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      amount INTEGER NOT NULL CHECK(amount >= 0),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS debts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT NOT NULL,
      original_amount INTEGER NOT NULL CHECK(original_amount > 0),
      remaining_amount INTEGER NOT NULL CHECK(remaining_amount >= 0),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS debt_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      debt_id INTEGER NOT NULL REFERENCES debts(id),
      amount INTEGER NOT NULL CHECK(amount > 0),
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at);
    CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
  `);
}

export async function addProduct(db:DB,p:{name:string;barcode:string|null;buyPrice:number;sellPrice:number;quantity:number;threshold:number}) {
  if (!p.name.trim()) throw new Error('أدخل اسم المنتج.');
  if (![p.buyPrice,p.sellPrice,p.quantity,p.threshold].every(Number.isFinite)) throw new Error('تحقق من الأرقام المدخلة.');
  if (p.buyPrice<0||p.sellPrice<0||p.quantity<0||p.threshold<0||!Number.isInteger(p.quantity)||!Number.isInteger(p.threshold)) throw new Error('الأسعار والكمية يجب أن تكون قيمًا صحيحة غير سالبة.');
  try {
    await db.runAsync('INSERT INTO products(name,barcode,buy_price,sell_price,quantity,low_stock_threshold,created_at) VALUES(?,?,?,?,?,?,?)',p.name.trim(),p.barcode,p.buyPrice,p.sellPrice,p.quantity,p.threshold,now());
  } catch(e:any) { if(String(e?.message).toLowerCase().includes('unique')) throw new Error('هذا الباركود مسجل لمنتج آخر.'); throw e; }
}

export async function listProducts(db:DB) {
  return db.getAllAsync<any>('SELECT * FROM products ORDER BY name COLLATE NOCASE');
}

export async function createSale(db:DB,s:{barcode:string;quantity:number;discount:number;idempotencyKey:string}) {
  if (!s.barcode) throw new Error('أدخل باركود المنتج.');
  if (!Number.isInteger(s.quantity)||s.quantity<=0) throw new Error('الكمية المباعة يجب أن تكون عددًا صحيحًا أكبر من صفر.');
  if (!Number.isInteger(s.discount)||s.discount<0) throw new Error('الخصم غير صالح.');
  if (!s.idempotencyKey) throw new Error('مفتاح العملية مفقود.');
  await db.withTransactionAsync(async()=>{
    const prior = await db.getFirstAsync<any>('SELECT id FROM sales WHERE idempotency_key=?',s.idempotencyKey);
    if(prior) throw new Error(`هذه العملية مسجلة مسبقًا برقم ${prior.id} ولم يتم خصم المخزون مرة أخرى.`);
    const product = await db.getFirstAsync<any>('SELECT * FROM products WHERE barcode=?',s.barcode);
    if(!product) throw new Error('لم يتم العثور على منتج بهذا الباركود.');
    if(product.quantity<s.quantity) throw new Error(`المخزون غير كافٍ. المتوفر: ${product.quantity}.`);
    const subtotal = product.sell_price*s.quantity;
    if(s.discount>subtotal) throw new Error('الخصم لا يمكن أن يتجاوز إجمالي البيع.');
    const total=subtotal-s.discount;
    const profit=total-product.buy_price*s.quantity;
    const result=await db.runAsync('INSERT INTO sales(idempotency_key,subtotal,discount,total,estimated_profit,created_at) VALUES(?,?,?,?,?,?)',s.idempotencyKey,subtotal,s.discount,total,profit,now());
    const saleId=result.lastInsertRowId;
    const update=await db.runAsync('UPDATE products SET quantity=quantity-? WHERE id=? AND quantity>=?',s.quantity,product.id,s.quantity);
    if(update.changes!==1) throw new Error('تغير المخزون أثناء البيع. أعد المحاولة.');
    await db.runAsync('INSERT INTO sale_items(sale_id,product_id,product_name,quantity,unit_buy_price,unit_sell_price,line_total) VALUES(?,?,?,?,?,?,?)',saleId,product.id,product.name,s.quantity,product.buy_price,product.sell_price,total);
  });
}

export async function addExpense(db:DB,title:string,amount:number) {
  if(!title.trim()) throw new Error('أدخل وصف المصروف.');
  if(!Number.isInteger(amount)||amount<0) throw new Error('المبلغ غير صالح.');
  await db.runAsync('INSERT INTO expenses(title,amount,created_at) VALUES(?,?,?)',title.trim(),amount,now());
}

export async function addCustomerDebt(db:DB,name:string,amount:number) {
  if(!name.trim()) throw new Error('أدخل اسم العميل.');
  if(!Number.isInteger(amount)||amount<=0) throw new Error('قيمة الدين يجب أن تكون أكبر من صفر.');
  await db.runAsync('INSERT INTO debts(customer_name,original_amount,remaining_amount,created_at) VALUES(?,?,?,?)',name.trim(),amount,amount,now());
}

export async function recordDebtPayment(db:DB,debtId:number,amount:number) {
  if(!Number.isInteger(debtId)||debtId<=0) throw new Error('رقم الدين غير صالح.');
  if(!Number.isInteger(amount)||amount<=0) throw new Error('قيمة السداد يجب أن تكون أكبر من صفر.');
  await db.withTransactionAsync(async()=>{
    const debt=await db.getFirstAsync<any>('SELECT * FROM debts WHERE id=?',debtId);
    if(!debt) throw new Error('لم يتم العثور على الدين.');
    if(amount>debt.remaining_amount) throw new Error(`المبلغ أكبر من المتبقي (${debt.remaining_amount}).`);
    await db.runAsync('INSERT INTO debt_payments(debt_id,amount,created_at) VALUES(?,?,?)',debtId,amount,now());
    await db.runAsync('UPDATE debts SET remaining_amount=remaining_amount-? WHERE id=?',amount,debtId);
  });
}

export async function getDashboard(db:DB) {
  const today=dateKey();
  const month=today.slice(0,7);
  const salesToday=await db.getFirstAsync<any>('SELECT COALESCE(SUM(total),0) AS value FROM sales WHERE substr(created_at,1,10)=?',today);
  const salesMonth=await db.getFirstAsync<any>('SELECT COALESCE(SUM(total),0) AS value FROM sales WHERE substr(created_at,1,7)=?',month);
  const products=await db.getFirstAsync<any>('SELECT COUNT(*) AS value FROM products');
  const low=await db.getFirstAsync<any>('SELECT COUNT(*) AS value FROM products WHERE quantity<=low_stock_threshold');
  const debts=await db.getAllAsync<any>('SELECT * FROM debts WHERE remaining_amount>0 ORDER BY created_at DESC');
  return {todaySales:salesToday?.value??0,monthSales:salesMonth?.value??0,productCount:products?.value??0,lowStock:low?.value??0,debts};
}

export async function exportBackup(db:DB) {
  const payload:any={format:'mizan-backup',version:1,exportedAt:now(),data:{}};
  for(const table of ['products','sales','sale_items','expenses','debts','debt_payments']) {
    payload.data[table]=await db.getAllAsync<any>(`SELECT * FROM ${table}`);
  }
  const uri=(FileSystem.cacheDirectory||FileSystem.documentDirectory)+'mizan-backup-'+Date.now()+'.json';
  await FileSystem.writeAsStringAsync(uri,JSON.stringify(payload,null,2));
  if(await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri,{mimeType:'application/json',dialogTitle:'نسخة احتياطية لميزان المخزون'});
  else throw new Error('المشاركة غير متاحة على هذا الجهاز. الملف محفوظ مؤقتًا في التطبيق.');
}

export async function importBackup(db:DB) {
  const picked=await DocumentPicker.getDocumentAsync({type:'application/json',copyToCacheDirectory:true});
  if(picked.canceled) return;
  const text=await FileSystem.readAsStringAsync(picked.assets[0].uri);
  let payload:any;
  try { payload=JSON.parse(text); } catch { throw new Error('ملف JSON غير صالح.'); }
  const tables=['products','sales','sale_items','expenses','debts','debt_payments'];
  if(payload?.format!=='mizan-backup'||payload?.version!==1||!payload?.data||!tables.every(t=>Array.isArray(payload.data[t]))) throw new Error('صيغة النسخة الاحتياطية غير مدعومة.');
  // Validate key constraints before destructive replacement.
  for(const p of payload.data.products) if(typeof p.name!=='string'||!Number.isInteger(p.quantity)||p.quantity<0||!Number.isInteger(p.buy_price)||!Number.isInteger(p.sell_price)) throw new Error('بيانات المنتجات في النسخة غير صالحة.');
  await db.withTransactionAsync(async()=>{
    await db.execAsync('DELETE FROM debt_payments; DELETE FROM sale_items; DELETE FROM sales; DELETE FROM expenses; DELETE FROM debts; DELETE FROM products;');
    for(const t of tables) {
      const rows=payload.data[t];
      for(const row of rows) {
        const keys=Object.keys(row);
        if(!keys.length||keys.some(k=>!/^[a-z_]+$/.test(k))) throw new Error('حقل غير صالح في النسخة الاحتياطية.');
        const placeholders=keys.map(()=>'?').join(',');
        await db.runAsync(`INSERT INTO ${t} (${keys.join(',')}) VALUES (${placeholders})`,...keys.map(k=>row[k]??null));
      }
    }
  });
}
