import { useState } from 'react';
import { Modal, Text, TouchableOpacity, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { styles } from '../lib/styles';

export function BarcodeScanner({onResult,onClose}:{onResult:(value:string)=>void;onClose:()=>void}) {
  const [permission,requestPermission]=useCameraPermissions();
  const [locked,setLocked]=useState(false);
  return <Modal visible animationType="slide" onRequestClose={onClose}>
    <View style={{flex:1,backgroundColor:'#111827',justifyContent:'center',padding:18}}>
      <Text style={{color:'#fff',fontSize:20,textAlign:'center',marginBottom:18}}>مسح باركود المنتج</Text>
      {!permission?.granted ? <TouchableOpacity style={styles.button} onPress={requestPermission}><Text style={styles.buttonText}>السماح باستخدام الكاميرا</Text></TouchableOpacity> :
        <CameraView style={{height:360,width:'100%'}} facing="back" barcodeScannerSettings={{barcodeTypes:['ean13','ean8','upc_a','upc_e','code128','qr']}}
          onBarcodeScanned={locked?undefined:({data})=>{setLocked(true);onResult(data)}} />}
      <TouchableOpacity style={[styles.button,{marginTop:20}]} onPress={onClose}><Text style={styles.buttonText}>إغلاق</Text></TouchableOpacity>
    </View>
  </Modal>;
}
