export function money(halalas:number) {
  const value=(Number(halalas||0)/100).toLocaleString('ar-SA',{minimumFractionDigits:2,maximumFractionDigits:2});
  return `${value} ر.س`;
}
export function parseAmount(value:string) {
  const n=Number(value);
  if(!Number.isFinite(n)||n<0) throw new Error('أدخل مبلغًا صحيحًا.');
  // Convert Saudi Riyal input to integer halalas.
  return Math.round((n+Number.EPSILON)*100);
}
export function todayKey() { return new Date().toISOString().slice(0,10); }
