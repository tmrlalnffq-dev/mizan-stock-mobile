import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SQLiteProvider } from 'expo-sqlite';
import { initializeDatabase } from '../src/db/database';

export default function RootLayout() {
  return (
    <SQLiteProvider databaseName="mizan.db" onInit={initializeDatabase}>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false }} />
    </SQLiteProvider>
  );
}
