import { useEffect, useState } from 'react';
import { Alert, ScrollView, Text, TextInput, TouchableOpacity, View, I18nManager } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { addProduct, createSale, addExpense, addCustomerDebt, recordDebtPayment, getDashboard, listProducts, exportBackup, importBackup } from '../src/db/database';
import { money, parseAmount, todayKey } from '../src/lib/format';
import { BarcodeScanner } from '../src/components/BarcodeScanner';
import { styles } from '../src/lib/styles';

type Tab = 'home'|'products'|'sale'|'expenses'|'debts'|'backup';

I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

export default function Home() {
  const db = useSQLiteContext();
  const [tab,setTab] = useState<Tab>('home');
  const [refresh,setRefresh] = useState(0);
  const [dashboard,setDashboard] = useState<any>({todaySales:0,monthSales:0,productCount:0,lowStock:0});
  const [products,setProducts] = useState<any[]>([]);
  const [name,setName] = useState(''); const [barcode,setBarcode] = useState('');
  const [buy,setBuy] = useState(''); const [sell,setSell] = useState(''); const [qty,setQty] = useState(''); const [threshold,setThreshold] = useState('3');
  const [saleBarcode,setSaleBarcode] = useState(''); const [saleQty,setSaleQty] = useState('1'); const [discount,setDiscount] = useState('0');
  const [saleKey,setSaleKey] = useState(()=>`sale-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const [expenseTitle,setExpenseTitle] = useState(''); const [expenseAmount,setExpenseAmount] = useState('');
  const [customer,setCustomer] = useState(''); const [debtAmount,setDebtAmount] = useState('');
  const [payId,setPayId] = useState(''); const [payAmount,setPayAmount] = useState('');
  const [scanFor,setScanFor] = useState<'product'|'sale'|null>(null);

  async function load() {
    try { setDashboard(await getDashboard(db)); setProducts(await listProducts(db)); }
    catch(e:any) { Alert.alert('خطأ في تحميل البيانات', e?.message ?? 'حدث خطأ غير معروف'); }
  }
  useEffect(()=>{ load(); },[refresh,db]);
  const run = async (fn:()=>Promise<any>, success:string) => {
    try { await fn(); Alert.alert('تم',success); setRefresh(x=>x+1); }
    catch(e:any) { Alert.alert('تعذر تنفيذ العملية', e?.message ?? 'تحقق من المدخلات ثم حاول مجددًا'); }
  };
  const input = (label:string,value:string,set:(v:string)=>void,keyboardType:any='default') => (
    <View style={styles.field} key={label}><Text style={styles.label}>{label}</Text>
      <TextInput value={value} onChangeText={set} keyboardType={keyboardType} style={styles.input} placeholder={label} />
    </View>
  );
  const button = (label:string,onPress:()=>void,secondary=false) => <TouchableOpacity key={label} onPress={onPress} style={[styles.button,secondary&&styles.secondary]}><Text style={styles.buttonText}>{label}</Text></TouchableOpacity>;
  const header = (title:string) => <Text style={styles.heading}>{title}</Text>;

  return <View style={styles.screen}>
    <Text style={styles.appTitle}>ميزان المخزون</Text>
    <Text style={styles.subtitle}>إدارة المبيعات والمخزون — البيانات محفوظة محليًا</Text>
    <View style={styles.tabs}>
      {([['home','الرئيسية'],['products','المنتجات'],['sale','بيع'],['expenses','المصروفات'],['debts','الديون'],['backup','النسخ الاحتياطي']] as [Tab,string][]).map(([key,label])=>
        <TouchableOpacity key={key} onPress={()=>setTab(key)} style={[styles.tab,tab===key&&styles.activeTab]}><Text style={styles.tabText}>{label}</Text></TouchableOpacity>)}
    </View>
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      {tab==='home' && <>
        {header('ملخص النشاط')}
        <View style={styles.cards}>
          <View style={styles.card}><Text style={styles.cardLabel}>مبيعات اليوم</Text><Text style={styles.cardValue}>{money(dashboard.todaySales)}</Text></View>
          <View style={styles.card}><Text style={styles.cardLabel}>مبيعات الشهر</Text><Text style={styles.cardValue}>{money(dashboard.monthSales)}</Text></View>
          <View style={styles.card}><Text style={styles.cardLabel}>عدد المنتجات</Text><Text style={styles.cardValue}>{dashboard.productCount}</Text></View>
          <View style={styles.card}><Text style={styles.cardLabel}>مخزون منخفض</Text><Text style={styles.cardValue}>{dashboard.lowStock}</Text></View>
        </View>
        {header('تنبيهات المخزون')}
        {products.filter(p=>p.quantity<=p.low_stock_threshold).length===0?<Text style={styles.muted}>لا توجد منتجات منخفضة المخزون.</Text>:
          products.filter(p=>p.quantity<=p.low_stock_threshold).map(p=><Text key={p.id} style={styles.listItem}>⚠ {p.name} — المتبقي: {p.quantity}</Text>)}
        <Text style={styles.note}>الربح المعروض تقديري ولا يشمل الضرائب أو التكاليف غير المسجلة.</Text>
      </>}
      {tab==='products' && <>
        {header('إضافة منتج')}
        {input('اسم المنتج',name,setName)}
        <View style={styles.row}>{input('الباركود',barcode,setBarcode)}{button('مسح باركود',()=>setScanFor('product'),true)}</View>
        {input('سعر الشراء',buy,setBuy,'decimal-pad')}
        {input('سعر البيع',sell,setSell,'decimal-pad')}
        {input('الكمية الابتدائية',qty,setQty,'number-pad')}
        {input('حد تنبيه انخفاض المخزون',threshold,setThreshold,'number-pad')}
        {button('حفظ المنتج',()=>run(async()=>{await addProduct(db,{name,barcode:barcode.trim()||null,buyPrice:parseAmount(buy),sellPrice:parseAmount(sell),quantity:Number(qty),threshold:Number(threshold)});setName('');setBarcode('');setBuy('');setSell('');setQty('');},'تم حفظ المنتج'))}
        {header('قائمة المنتجات')}
        {products.map(p=><View key={p.id} style={styles.listCard}><Text style={styles.listTitle}>{p.name}</Text><Text>باركود: {p.barcode||'غير مسجل'}</Text><Text>شراء: {money(p.buy_price)} | بيع: {money(p.sell_price)}</Text><Text>الكمية: {p.quantity}</Text></View>)}
        {scanFor==='product'&&<BarcodeScanner onResult={v=>{setBarcode(v);setScanFor(null)}} onClose={()=>setScanFor(null)}/>}
      </>}
      {tab==='sale' && <>
        {header('تسجيل عملية بيع')}
        {input('باركود المنتج',saleBarcode,setSaleBarcode)}
        {button('مسح باركود',()=>setScanFor('sale'),true)}
        {input('الكمية المباعة',saleQty,setSaleQty,'number-pad')}
        {input('الخصم الإجمالي (بالعملة المحلية)',discount,setDiscount,'decimal-pad')}
        {button('تأكيد البيع وخصم المخزون',()=>run(async()=>{await createSale(db,{barcode:saleBarcode.trim(),quantity:Number(saleQty),discount:parseAmount(discount),idempotencyKey:saleKey});setSaleBarcode('');setSaleQty('1');setDiscount('0');setSaleKey(`sale-${Date.now()}-${Math.random().toString(36).slice(2)}`);},'تم تسجيل البيع وتحديث المخزون'))}
        <Text style={styles.note}>كل ضغطة تأكيد جديدة تنشئ عملية بيع مستقلة. لا تضغط تأكيد مرة ثانية لنفس الفاتورة. آلية منع التكرار تعمل عند إعادة إرسال نفس مفتاح العملية.</Text>
        {scanFor==='sale'&&<BarcodeScanner onResult={v=>{setSaleBarcode(v);setScanFor(null)}} onClose={()=>setScanFor(null)}/>}
      </>}
      {tab==='expenses' && <>
        {header('تسجيل مصروف')}
        {input('وصف المصروف',expenseTitle,setExpenseTitle)}
        {input('المبلغ',expenseAmount,setExpenseAmount,'decimal-pad')}
        {button('حفظ المصروف',()=>run(async()=>{await addExpense(db,expenseTitle,parseAmount(expenseAmount));setExpenseTitle('');setExpenseAmount('');},'تم حفظ المصروف'))}
      </>}
      {tab==='debts' && <>
        {header('تسجيل دين عميل')}
        {input('اسم العميل',customer,setCustomer)}
        {input('المبلغ المستحق',debtAmount,setDebtAmount,'decimal-pad')}
        {button('حفظ الدين',()=>run(async()=>{await addCustomerDebt(db,customer,parseAmount(debtAmount));setCustomer('');setDebtAmount('');},'تم تسجيل الدين'))}
        {header('تسجيل دفعة على دين')}
        {input('رقم الدين (ID)',payId,setPayId,'number-pad')}
        {input('المبلغ المسدد',payAmount,setPayAmount,'decimal-pad')}
        {button('تسجيل السداد',()=>run(async()=>{await recordDebtPayment(db,Number(payId),parseAmount(payAmount));setPayId('');setPayAmount('');},'تم تسجيل السداد'))}
        {header('الديون القائمة')}
        {(dashboard.debts||[]).map((d:any)=><View key={d.id} style={styles.listCard}><Text style={styles.listTitle}>#{d.id} — {d.customer_name}</Text><Text>الأصل: {money(d.original_amount)} | المتبقي: {money(d.remaining_amount)}</Text></View>)}
      </>}
      {tab==='backup' && <>
        {header('النسخ الاحتياطي')}
        <Text style={styles.note}>التصدير ينشئ ملف JSON من بيانات التطبيق. احفظه في مكان خاص وآمن؛ الملف غير مشفر في هذه النسخة.</Text>
        {button('تصدير نسخة احتياطية',()=>run(()=>exportBackup(db),'تم إنشاء ملف النسخة الاحتياطية'))}
        {button('استعادة من ملف JSON',()=>Alert.alert('تنبيه قبل الاستعادة','سيتم استبدال بيانات التطبيق الحالية. هل تريد المتابعة؟',[{text:'إلغاء',style:'cancel'},{text:'متابعة',style:'destructive',onPress:()=>run(()=>importBackup(db),'تمت استعادة البيانات')}]),true)}
        <Text style={styles.note}>الاستعادة تستبدل البيانات الحالية. خذ نسخة احتياطية جديدة أولًا. لا تستورد ملفًا من مصدر غير موثوق.</Text>
      </>}
    </ScrollView>
  </View>;
}
