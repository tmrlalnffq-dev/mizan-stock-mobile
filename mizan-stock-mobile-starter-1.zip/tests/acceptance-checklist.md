# Manual acceptance checklist

Run these checks on a device/emulator with a fresh app install.

- [ ] App opens with an empty database (no seeded/sample products).
- [ ] Add a product with a unique barcode, purchase price, selling price, quantity.
- [ ] Adding a duplicate barcode produces a clear error and does not create a second product.
- [ ] Attempt sale with an unknown barcode; sale fails and stock remains unchanged.
- [ ] Attempt sale quantity greater than stock; sale fails and stock remains unchanged.
- [ ] Sell quantity 2 from stock 5; stock becomes 3 and sale total is correct.
- [ ] Discount greater than subtotal is rejected.
- [ ] Re-submit the same `idempotencyKey` using a test harness; second attempt fails and stock is not deducted again.
- [ ] Expense rejects blank title and invalid/negative amount.
- [ ] Debt payment cannot exceed remaining debt.
- [ ] Low-stock warning appears when quantity is at/below threshold.
- [ ] Export JSON, install/clear test data, import the JSON, verify tables and IDs.
- [ ] Malformed JSON is rejected before existing data is deleted.
- [ ] Verify daily/monthly totals against manually calculated sales.
- [ ] Test barcode camera permission denied/granted.
- [ ] Test RTL on target Android devices.

Note: this checklist documents tests to perform; it does not claim the tests have already been executed.
